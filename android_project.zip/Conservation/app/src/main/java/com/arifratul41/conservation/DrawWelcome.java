package com.arifratul41.conservation;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Picture;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

/**
 * Created by miao on 12/10/15.
 */
public class DrawWelcome extends View {
    Paint paint = new Paint();
    Paint tpaint = new Paint();
    private double center_x, center_y, bob_x, bob_y, len;
    private double angle;
    private double KE, PE, TE;
    int cnt = 0;

    public DrawWelcome(Context context) {
        super(context);
        setFocusable(true);
        setFocusableInTouchMode(true);
       // this.setOnTouchListener(this);
        paint = new Paint();
        paint.setAntiAlias(true);
        paint.setDither(true);
        paint.setColor(Color.BLACK);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeJoin(Paint.Join.ROUND);
        paint.setStrokeCap(Paint.Cap.ROUND);
        paint.setStrokeWidth(10);

        tpaint.setTextSize(30);
        tpaint.setTextAlign(Paint.Align.CENTER);

        angle = 0;
    }

    @Override
    public void onDraw(Canvas canvas) {
        final ImageView iv = (ImageView) findViewById(R.id.imageView);
        Picture picture = new Picture();
        //canvas.drawPicture();
    }
}