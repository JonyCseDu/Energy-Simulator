package com.arifratul41.conservation;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by miao on 12/10/15.
 */
public class Description extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }
}
